<nav class="nav">
    <a class="nav-item" href="index.php">
        <img src="image/logo_white.svg" alt="Deep新宿">
    </a>
    <a class="nav-item" href="about.php">About</a>
</nav>