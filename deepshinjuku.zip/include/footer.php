<footer class="footer">
  <a href="index.php">
    <div class="footer-logo">
      <img src="image/logo.svg" alt="Deep新宿">
    </div>
  </a>
  <div class="copyright">
    <p>©2024 コードの森 All rights reserved.</p>
  </div>
</footer>